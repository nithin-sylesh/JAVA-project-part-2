import java.util.*;

public class projectphase1_AM.EN.U4AIE19044_Nithin sylesh_2a {
    public static void main(String[] main) {
        Queue_linkedlist q1 = new Queue_linkedlist();
        Scanner in = new Scanner(System.in);
        int choice = -1;
        int x = 0;
        while (choice != 0) {
            System.out.println("Enter your choice:");
            String st[] = in.nextLine().split(" ");
            choice = Integer.parseInt(st[0]);
            if (st.length > 1) {
                x = Integer.parseInt(st[1]);
            }

            switch (choice) {
                case 0:
                    break;
                case 1:
                    if (st.length > 1) {
                        q1.enqueue(x);
                    } else {
                        System.out.println("Please enter value to be pushed with choice. i.e - \"1 2\"");
                    }
                    break;
                case 2:
                    q1.dequeue();
                    break;
                case 3:
                    q1.peek();
                    break;
                case 4:
                    q1.show();
                    break;
                default:
                    System.out.println("Error, please stick to instructions mentioned in pdf.");
            }
        }
    }
}

class Node {
    int data;
    Node next;

    Node(int item) {
        data = item;
        next = null;
    }
}

class Queue_linkedlist {
    Node front, rear;

    void enqueue(int item) {
        Node temp = new Node(item);
        if (this.rear == null) {
            this.front = this.rear = temp;
            return;
        }
        this.rear.next = temp;
        this.rear = temp;
    }

    Node dequeue() {
        if (isEmpty()) {
            System.out.println("EMPTY");
            return null;
        }
        Node temp = front;
        front = front.next;
        if (front == null) {
            rear = null;
        }
        System.out.println(temp.data);
        return temp;
    }

    Node peek() {
        if (isEmpty()) {
            System.out.println("EMPTY");
            return null;
        }
        System.out.println(front.data);
        return front;
    }

    void show() {
        if (isEmpty()) {
            System.out.println("EMPTY");
            return;
        }
        Node temp = front;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    boolean isEmpty() {
        return (front == null);
    }
}
