import java.util.*;

public class projectphase1_AM.EN.U4AIE19044_Nithin sylesh_2b {
    public static void main(String[] main) {
        Queue_array q2 = new Queue_array();
        Scanner in = new Scanner(System.in);
        int choice = -1;
        int x = 0;
        while (choice != 0) {
            System.out.println("Enter your choice:");
            String st[] = in.nextLine().split(" ");
            choice = Integer.parseInt(st[0]);
            if (st.length > 1) {
                x = Integer.parseInt(st[1]);
            }

            switch (choice) {
                case 0:
                    break;
                case 1:
                    if (st.length > 1) {
                        q2.enqueue(x);
                    } else {
                        System.out.println("Please enter value to be pushed with choice. i.e - \"1 2\"");
                    }
                    break;
                case 2:
                    q2.dequeue();
                    break;
                case 3:
                    q2.peek();
                    break;
                case 4:
                    q2.show();
                    break;
                default:
                    System.out.println("Error, please stick to instructions mentioned in pdf.");
            }
        }
    }
}

class Node {
    int data;
    Node next;

    Node(int item) {
        data = item;
        next = null;
    }
}

class Queue_array {
    int[] ar;
    int front;
    int rear;
    int current_size;
    static int MAX;

    Queue_array() {
        front = -1;
        rear = -1;
        Scanner in = new Scanner(System.in);
        System.out.println("Enter size of queue.");
        boolean flag = false;
        while (!flag) {
            MAX = in.nextInt();
            if (MAX > 0 && MAX < 100) {
                ar = new int[MAX];
                flag = true;
            } else {
                System.out.println("Array size has to be in between 0 and 100. Enter value again.");
            }
        }
        current_size = 0;
    }

    boolean isEmpty() {
        return (front == -1 && rear == -1);
    }

    void show() {
        if (front == -1) {
            System.out.println("EMPTY");
            return;
        }
        for (int i = front; i != rear + 1; i = (i + 1) % MAX) {
            System.out.print(ar[i] + " ");
        }
        System.out.println();
    }

    void enqueue(int item) {
        if (current_size == MAX) {
            System.out.println("OVERFLOW");
        } else if (isEmpty()) {
            front++;
            rear++;
            ar[rear] = item;
            current_size++;
        } else {
            rear = (rear + 1) % MAX;
            ar[rear] = item;
            current_size++;
        }
    }

    int peek() {
        if (front == -1) {
            System.out.println("EMPTY");
            return -1;
        } else {
            System.out.println(ar[front]);
            return ar[front];
        }
    }

    int dequeue() {
        int temp;
        if (isEmpty()) {
            System.out.println("EMPTY");
            return -1;
        } else if (front == rear) {
            temp = ar[front];
            front = -1;
            rear = -1;
            current_size--;
            System.out.println(temp);
            return temp;
        } else {
            temp = ar[front];
            front = (front + 1) % MAX;
            current_size--;
            System.out.println(temp);
            return temp;
        }
    }
}
