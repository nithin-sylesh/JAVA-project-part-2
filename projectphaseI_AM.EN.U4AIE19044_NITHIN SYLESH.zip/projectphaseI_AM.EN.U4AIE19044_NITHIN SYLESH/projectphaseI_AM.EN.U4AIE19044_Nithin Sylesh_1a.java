import java.util.*;
import java.lang.String;

public class projectphase1_AM.EN.U4AIE19044_Nithin Sylesh_1a {
    public static void main(String[] main) {
        Stack_linkedlist st1 = new Stack_linkedlist();
        Scanner in = new Scanner(System.in);
        int choice = -1;
        int x = 0;
        while (choice != 0) {
            System.out.println("Enter your choice:");
            String[] st = in.nextLine().split(" ");
            choice = Integer.parseInt(st[0]);
            if (st.length > 1) {
                x = Integer.parseInt(st[1]);
            }

            switch (choice) {
                case 0:
                    break;
                case 1:
                    if (x < 0) {
                        System.out.println("Integer must be positive");
                        break;
                    }
                    if (st.length > 1) {
                        st1.push(x);
                    } else {
                        System.out.println("Please enter value to be pushed with choice. i.e - \"1 2\"");
                    }
                    break;
                case 2:
                    st1.pop();
                    break;
                case 3:
                    st1.peek();
                    break;
                case 4:
                    st1.show();
                    break;
                default:
                    System.out.println("Error, please stick to instructions mentioned in pdf.");
            }
        }
    }
}

class Node {
    int data;
    Node next;

    Node(int item) {
        data = item;
        next = null;
    }
}

class Stack_linkedlist {
    Node top = null;

    void push(int item) {
        Node next_node = new Node(item);
        if (isEmpty()) {
            top = next_node;
            return;
        }
        next_node.next = top;
        top = next_node;
    }

    void pop() {
        if (isEmpty()) {
            System.out.println("EMPTY");
            return;
        }
        System.out.println(top.data);
        top = top.next;
    }

    void show() {
        if (isEmpty()) {
            System.out.println("EMPTY");
            return;
        }
        Node temp = top;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    int peek() {
        if (isEmpty()) {
            System.out.println("EMPTY");
            return -1;
        }
        System.out.println(top.data);
        return top.data;
    }

    boolean isEmpty() {
        return (top == null);
    }
}

