import java.util.*;
import java.lang.String;

public class projectphase1_AM.EN.U4AIE19044_Nithin sylesh_1b {
    public static void main(String[] main) {
        Stack_array st1 = new Stack_array();
        Scanner in = new Scanner(System.in);
        int choice = -1;
        int x = 0;
        while (choice != 0) {
            System.out.println("Enter your choice:");
            String st[] = in.nextLine().split(" ");
            choice = Integer.parseInt(st[0]);
            if (st.length > 1) {
                x = Integer.parseInt(st[1]);
            }
            switch (choice) {
                case 0:
                    break;
                case 1:
                    if (x < 0) {
                        System.out.println("Integer must be positive");
                        break;
                    }
                    if (st.length > 1) {
                        st1.push(x);
                    } else {
                        System.out.println("Please enter value to be pushed with choice. i.e - \"1 2\"");
                    }
                    break;
                case 2:
                    st1.pop();
                    break;
                case 3:
                    st1.peek();
                    break;
                case 4:
                    st1.show();
                    break;
                default:
                    System.out.println("Error, please stick to instructions mentioned in pdf.");
            }
        }
    }
}

class Node {
    int data;
    Node next;

    Node(int item) {
        data = item;
        next = null;
    }
}

class Stack_array {
    static int MAX;
    int top;
    int[] ar;

    Stack_array() {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter size of stack.");
        top = -1;
        boolean flag = false;
        while (!flag) {
            MAX = in.nextInt();
            if (MAX > 0 && MAX < 100) {
                ar = new int[MAX];
                flag = true;
            } else {
                System.out.println("Array size has to be in between 0 and 100. Enter value again.");
            }
        }
    }

    void push(int item) {
        if (top == MAX - 1) {
            System.out.println("OVERFLOW");
            return;
        }
        top++;
        ar[top] = item;
    }

    void pop() {
        if (top < 0) {
            System.out.println("EMPTY");
            return;
        }
        System.out.println(ar[top]);
        top--;
    }

    void peek() {
        if (top < 0) {
            System.out.println("EMPTY");
            return;
        }
        System.out.println(ar[top]);
    }

    void show() {
        if (top < 0) {
            System.out.println("EMPTY");
            return;
        }
        for (int i = top; i >= 0; i--) {
            System.out.print(ar[i] + " ");
        }
        System.out.println();
    }
}
